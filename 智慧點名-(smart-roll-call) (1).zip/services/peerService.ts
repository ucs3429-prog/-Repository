// Declare PeerJS global type
declare const Peer: any;

export type PeerStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface P2PData {
    type: 'CHECK_IN' | 'HANDSHAKE';
    payload: any;
}

class PeerService {
    private peer: any;
    private conn: any;
    private status: PeerStatus = 'disconnected';
    private onStatusChangeCallbacks: ((status: PeerStatus) => void)[] = [];
    private onDataCallbacks: ((data: P2PData) => void)[] = [];

    // --- HOST METHODS (TEACHER) ---
    
    // Generate a short ID for the room (6 chars for better uniqueness on public cloud)
    public generateRoomId(): string {
        return Math.random().toString(36).substring(2, 8).toUpperCase();
    }

    public initializeHost(roomId: string) {
        if (this.peer) this.peer.destroy();
        this.updateStatus('connecting');

        // Create a peer with a specific ID: "STAGE-DOOR-{RoomID}"
        // This makes it easy for students to connect if they know the room ID
        const peerId = `STAGE-DOOR-${roomId}`;
        
        this.peer = new Peer(peerId, {
            debug: 1
        });

        this.peer.on('open', (id: string) => {
            console.log('Host initialized:', id);
            this.updateStatus('connected');
        });

        this.peer.on('connection', (conn: any) => {
            console.log('Student connected:', conn.peer);
            this.setupConnectionListeners(conn);
        });

        this.peer.on('error', (err: any) => {
            console.error('Peer error:', err);
            this.updateStatus('error');
        });

        this.peer.on('disconnected', () => {
            this.updateStatus('disconnected');
        });
    }

    // --- CLIENT METHODS (STUDENT) ---

    public connectToHost(roomId: string) {
        if (this.peer) this.peer.destroy();
        this.updateStatus('connecting');

        this.peer = new Peer({ debug: 1 }); // Client gets random ID

        this.peer.on('open', (id: string) => {
            console.log('Client initialized:', id);
            const hostId = `STAGE-DOOR-${roomId}`;
            const conn = this.peer.connect(hostId);
            this.setupConnectionListeners(conn);
        });

        this.peer.on('error', (err: any) => {
            console.error('Connect error:', err);
            this.updateStatus('error');
        });
    }

    public sendData(data: P2PData) {
        if (this.conn && this.conn.open) {
            this.conn.send(data);
            return true;
        }
        return false;
    }

    // --- SHARED ---

    private setupConnectionListeners(conn: any) {
        this.conn = conn;
        
        conn.on('open', () => {
            console.log('Connection established');
            this.updateStatus('connected');
            // Keep alive mechanism if needed
        });

        conn.on('data', (data: any) => {
            console.log('Received data:', data);
            this.onDataCallbacks.forEach(cb => cb(data));
        });

        conn.on('close', () => {
            console.log('Connection closed');
            this.updateStatus('disconnected'); // Or stay 'connected' as Peer, but 'disconnected' from specific user
        });

        conn.on('error', (err: any) => console.error('Conn error:', err));
    }

    // Status Management
    private updateStatus(s: PeerStatus) {
        this.status = s;
        this.onStatusChangeCallbacks.forEach(cb => cb(s));
    }

    public onStatusChange(cb: (status: PeerStatus) => void) {
        this.onStatusChangeCallbacks.push(cb);
        cb(this.status); // fire immediately
        return () => {
            this.onStatusChangeCallbacks = this.onStatusChangeCallbacks.filter(c => c !== cb);
        };
    }

    public onData(cb: (data: P2PData) => void) {
        this.onDataCallbacks.push(cb);
        return () => {
            this.onDataCallbacks = this.onDataCallbacks.filter(c => c !== cb);
        };
    }
    
    public getStatus() {
        return this.status;
    }

    public destroy() {
        if (this.peer) this.peer.destroy();
        this.peer = null;
        this.conn = null;
    }
}

export const peerService = new PeerService();