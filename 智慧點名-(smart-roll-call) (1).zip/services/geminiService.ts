import { GoogleGenAI, Type } from "@google/genai";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API_KEY is missing via process.env.API_KEY");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

/**
 * Parses a raw string of text to extract student names.
 */
export const parseStudentList = async (rawText: string): Promise<string[]> => {
  const ai = getAiClient();
  if (!ai) return rawText.split(/[\n,]/).map(s => s.trim()).filter(Boolean);

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Extract a list of student names from the following text. 
      Ignore numbers, IDs, or punctuation unless part of the name.
      Return ONLY a JSON array of strings.
      
      Text to parse:
      ${rawText}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error: any) {
    console.error("Gemini parse error:", error);
    return rawText.split(/[\n,]/).map(s => s.trim()).filter(Boolean);
  }
};

/**
 * Analyzes an image of a student roster/list and extracts names.
 */
export const parseStudentListFromImage = async (imagePart: { inlineData: { data: string; mimeType: string } }): Promise<string[]> => {
  const ai = getAiClient();
  if (!ai) throw new Error("AI Key missing");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          imagePart,
          { text: "Extract all student names visible in this image. Ignore IDs, grades, or other numbers. Return a JSON array of strings." }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini image parse error:", error);
    throw error;
  }
};

/**
 * Analyzes an image of a Class Schedule/Timetable and extracts course details.
 */
export const parseScheduleFromImage = async (imagePart: { inlineData: { data: string; mimeType: string } }): Promise<{name: string, subject: string}[]> => {
  const ai = getAiClient();
  if (!ai) throw new Error("AI Key missing");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          imagePart,
          { text: "Analyze this class schedule image. Extract distinct courses found. For 'name', use the course name. For 'subject', use the time/day or professor name if available, otherwise repeat the name. Return a JSON array of objects." }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              subject: { type: Type.STRING }
            }
          }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini schedule parse error:", error);
    throw error;
  }
};

/**
 * Generates a brief attendance report/insight.
 */
export const generateAttendanceInsight = async (
  className: string, 
  presentCount: number, 
  totalCount: number,
  absentNames: string[]
): Promise<string> => {
  const ai = getAiClient();
  const defaultMsg = `出席率: ${Math.round((presentCount/Math.max(totalCount,1))*100)}% (AI 暫時無法使用)`;
  
  if (!ai) return defaultMsg;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a helpful teaching assistant. Generate a very short, 2-sentence summary in Traditional Chinese for the teacher about today's attendance.
      
      Class: ${className}
      Present: ${presentCount}
      Total: ${totalCount}
      Absent Students: ${absentNames.join(', ')}
      
      Tone: Professional and encouraging. mention specific absent students if less than 3 are absent.`,
    });

    return response.text || "無法產生報告";
  } catch (error: any) {
    if (error?.status === 429 || error?.message?.includes('429')) {
       return `出席率: ${Math.round((presentCount/Math.max(totalCount,1))*100)}% (AI 額度已滿)`;
    }
    console.error("Gemini insight error:", error);
    return "AI 暫時無法使用";
  }
};

/**
 * Reverse Geocoding using OpenStreetMap (Primary) and Gemini (Secondary).
 * This ensures real-world accuracy similar to Google Maps.
 */
export const getAddressFromCoordinates = async (lat: number, lng: number): Promise<string> => {
  // Strategy 1: OpenStreetMap (Nominatim)
  // This is a standard, free, real-world mapping API that gives precise addresses.
  try {
    const osmResponse = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1&accept-language=zh-TW`,
      { headers: { 'User-Agent': 'SmartRollCallApp/1.0' } }
    );
    const osmData = await osmResponse.json();
    if (osmData && osmData.display_name) {
      // Clean up the address a bit if it's too long
      const parts = osmData.display_name.split(',');
      // Take the first 3-4 relevant parts for brevity
      return parts.slice(0, 3).join('').trim() || osmData.display_name;
    }
  } catch (osmError) {
    console.warn("OSM Geocoding failed, falling back to AI", osmError);
  }

  // Strategy 2: Gemini with Google Maps Grounding (Fallback)
  const ai = getAiClient();
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: "What is the precise street address or building name of this location in Taiwan? Provide ONLY the address in Traditional Chinese.",
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: lat,
                longitude: lng
              }
            }
          } as any 
        },
      });
      if (response.text) return response.text.trim();
    } catch (aiError) {
      console.error("Gemini geocoding error:", aiError);
    }
  }

  // Strategy 3: Coordinates fallback
  return `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
};