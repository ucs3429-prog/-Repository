export enum AttendanceStatus {
  PRESENT = 'PRESENT',
  ABSENT = 'ABSENT',
  LATE = 'LATE',
  EXCUSED = 'EXCUSED',
  UNSET = 'UNSET'
}

export interface Student {
  id: string;
  name: string;
}

export interface AttendanceRecord {
  studentId: string;
  status: AttendanceStatus;
  timestamp: number;
  location?: {
    lat: number;
    lng: number;
    altitude?: number | null; // Added altitude
    accuracy?: number; // Added accuracy
  };
  address?: string;
  checkInAttempts?: number; // Added to track how many tries it took
}

export interface ClassSession {
  id: string;
  date: string; // ISO Date string YYYY-MM-DD
  records: Record<string, AttendanceRecord>; // Map studentId to record
}

export interface ClassSchedule {
  dayOfWeek: number; // 0=Sunday, 1=Monday...
  startTime: string; // "09:00"
  endTime: string; // "12:00"
}

export interface LocationConfig {
  lat: number;
  lng: number;
  floor?: string; // e.g. "3F", "Room 401"
  radius?: number; // e.g. 50 meters
}

export interface Classroom {
  id: string;
  name: string;
  subject: string;
  schedule?: ClassSchedule; 
  defaultLocation?: LocationConfig;
  students: Student[];
  sessions: ClassSession[];
}

export interface AppState {
  classrooms: Classroom[];
}