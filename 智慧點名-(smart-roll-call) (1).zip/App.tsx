import React, { useState, useEffect, useCallback } from 'react';
import { Classroom, Student, ClassSession, AttendanceStatus, AttendanceRecord, LocationConfig } from './types';
import HomeView from './views/HomeView';
import AttendanceView from './views/AttendanceView';
import StudentCheckInView from './views/StudentCheckInView';
import { UserIcon, SparklesIcon, ShieldCheckIcon } from './components/Icon';
import { peerService, P2PData } from './services/peerService';

// Preset student list as requested
const PRESET_STUDENTS_LIST = [
  "C11454001邱名妤", "C11357028邱曉卿", "C11454008陳姵妤", "T11450001游亞倫",
  "C11454016楊佩慈", "C11454013謝長融", "C11454004許可欣", "C11454005王韻淇",
  "C11454021陳婷音", "T11454001 鄭婉伶", "C11454020伍凱文", "C11454016王郁婷",
  "C11454015楊佩慈"
];

type UserRole = 'student' | 'teacher' | null;

const App: React.FC = () => {
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [activeClassId, setActiveClassId] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>(null);
  
  // Test Mode State (In-App Simulation)
  const [testModeData, setTestModeData] = useState<{lat: number, lng: number, cls: string} | null>(null);

  // PeerJS / Room State
  const [roomId, setRoomId] = useState<string | null>(null);
  const [p2pStatus, setP2PStatus] = useState<string>('disconnected');

  // Check URL params for Student Mode (QR Code scan entry)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room');
    
    // If 'room' exists, auto-enter student mode and connect
    if (roomParam) {
        setUserRole('student');
        setRoomId(roomParam);
        peerService.connectToHost(roomParam);
    } else if (params.get('mode') === 'student') {
        setUserRole('student');
    }

    const unsubStatus = peerService.onStatusChange((s) => setP2PStatus(s));
    
    return () => unsubStatus();
  }, []);

  // Listen for P2P Data (Teacher Side)
  useEffect(() => {
      const unsubData = peerService.onData((data: P2PData) => {
          if (data.type === 'CHECK_IN' && userRole === 'teacher') {
             const payload = data.payload;
             // Payload structure from StudentCheckInView: 
             // { n: name, t: timestamp, l: locationObj, a: attempts, add: address, cls: className }
             
             console.log("P2P Check-in received:", payload);
             
             // Trigger internal check-in logic
             handleInternalCheckIn(
                 payload.n,
                 payload.l?.lat || 0,
                 payload.l?.lng || 0,
                 payload.add,
                 payload.l?.altitude,
                 payload.l?.accuracy,
                 payload.a
             );
             
             // Optional: visual feedback toast could go here
          }
      });
      return () => unsubData();
  }, [userRole]);

  const loadData = useCallback(() => {
    const saved = localStorage.getItem('smart-roll-call-data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
            setClassrooms(parsed);
            return;
        }
      } catch (e) {
        console.error("Failed to load data", e);
      }
    }
    
    // Initialize with Preset Data if LocalStorage is empty
    const defaultStudents: Student[] = PRESET_STUDENTS_LIST.map(name => ({
        id: crypto.randomUUID(),
        name: name
    }));
    
    // Default class with flexible schedule for demo
    const defaultClass: Classroom = {
        id: crypto.randomUUID(),
        name: '藝術表演',
        subject: '舞台劇',
        schedule: {
            dayOfWeek: new Date().getDay(),
            startTime: '00:00', 
            endTime: '23:59'
        },
        students: defaultStudents,
        sessions: []
    };
    setClassrooms([defaultClass]);
    localStorage.setItem('smart-roll-call-data', JSON.stringify([defaultClass]));
  }, []);

  // Load initial data
  useEffect(() => {
    loadData();
  }, [loadData]);

  // Listen for storage changes
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
        if (e.key === 'smart-roll-call-data') {
            loadData();
        }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [loadData]);

  // Save to LocalStorage
  useEffect(() => {
    if (classrooms.length > 0) { 
        localStorage.setItem('smart-roll-call-data', JSON.stringify(classrooms));
    }
  }, [classrooms]);

  const handleCreateClass = (
      name: string, 
      subject: string, 
      schedule?: {dayOfWeek: number, startTime: string, endTime: string},
      locationConfig?: LocationConfig
  ) => {
    const newClass: Classroom = {
      id: crypto.randomUUID(),
      name,
      subject,
      schedule,
      defaultLocation: locationConfig, // Save the fixed location
      students: [],
      sessions: []
    };
    setClassrooms(prev => [newClass, ...prev]);
  };

  const handleAddStudents = (classId: string, newStudents: Student[]) => {
    setClassrooms(prev => prev.map(c => {
      if (c.id === classId) {
        return { ...c, students: [...c.students, ...newStudents] };
      }
      return c;
    }));
  };

  const handleDeleteClass = (id: string) => {
    setClassrooms(prev => prev.filter(c => c.id !== id));
  };

  const handleSaveSession = (classId: string, session: ClassSession) => {
    setClassrooms(prev => prev.map(c => {
      if (c.id === classId) {
        const otherSessions = c.sessions.filter(s => s.date !== session.date);
        return { ...c, sessions: [...otherSessions, session] };
      }
      return c;
    }));
  };

  // UPDATED SIGNATURE: Accepts full location details and attempt count
  const handleInternalCheckIn = (
      studentNameInput: string, 
      lat: number, 
      lng: number, 
      address?: string,
      altitude?: number | null, 
      accuracy?: number, 
      attempts?: number
  ) => {
    const targetClassName = testModeData ? testModeData.cls : null;

    setClassrooms(prev => {
        return prev.map(cls => {
            // In Kiosk mode (no testModeData), we might check all classes or the active one.
            // Simplified logic: Check if student exists in this class.
            if (targetClassName && cls.name !== targetClassName) return cls;

            const cleanInput = studentNameInput.trim().replace(/\s/g, '');
            const student = cls.students.find(s => {
                const cleanName = s.name.replace(/\s/g, '');
                return cleanName.includes(cleanInput) || cleanInput.includes(cleanName);
            });

            if (!student) return cls;

            const today = new Date().toISOString().split('T')[0];
            const existingSession = cls.sessions.find(s => s.date === today);
            
            const newRecord: AttendanceRecord = {
                studentId: student.id,
                status: AttendanceStatus.PRESENT,
                timestamp: Date.now(),
                location: { lat, lng, altitude, accuracy },
                address: address || "Unknown Location",
                checkInAttempts: attempts
            };

            let newSessions = cls.sessions;

            if (existingSession) {
                 newSessions = cls.sessions.map(s => {
                     if (s.date !== today) return s;
                     return { ...s, records: { ...s.records, [student.id]: newRecord } };
                 });
            } else {
                const newSession: ClassSession = {
                    id: today,
                    date: today,
                    records: { [student.id]: newRecord }
                };
                newSessions = [...cls.sessions, newSession];
            }
            return { ...cls, sessions: newSessions };
        });
    });
  };

  // --- RENDER LOGIC ---

  // 1. Role Selection Screen
  if (!userRole && !testModeData) {
      return (
        <div className="w-full min-h-screen bg-stage-900 text-white flex flex-col items-center justify-center relative overflow-hidden p-6 perspective-container">
            <div className="absolute inset-0 pointer-events-none">
                 <div className="absolute top-[-10%] left-[20%] w-[60%] h-[60%] bg-stage-gold/10 rounded-full blur-[100px] animate-pulse"></div>
            </div>

            <h1 className="text-4xl font-display text-white mb-2 z-10 drop-shadow-lg">Stage Door</h1>
            <p className="text-gray-400 text-xs tracking-[0.3em] uppercase mb-12 z-10">Select Your Role / 選擇身分</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl z-10">
                <button 
                    onClick={() => setUserRole('student')}
                    className="group glass-stage p-8 rounded-2xl flex flex-col items-center gap-4 hover:bg-white/5 hover:scale-105 transition-all duration-300 border-t border-white/10"
                >
                    <div className="w-20 h-20 rounded-full bg-stage-800 flex items-center justify-center mb-2 group-hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all">
                        <UserIcon className="w-8 h-8 text-gray-300 group-hover:text-white" />
                    </div>
                    <div className="text-center">
                        <h2 className="text-2xl font-display text-gray-200 group-hover:text-white">Performer</h2>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">學生 / 演員</p>
                    </div>
                    <div className="mt-4 px-4 py-1 rounded-full border border-white/10 text-[9px] text-gray-400 uppercase tracking-wider group-hover:bg-white/10">
                        Check-in Access Only
                    </div>
                </button>

                <button 
                    onClick={() => setUserRole('teacher')}
                    className="group glass-stage p-8 rounded-2xl flex flex-col items-center gap-4 hover:bg-stage-gold/5 hover:scale-105 transition-all duration-300 border-t border-stage-gold/20 relative overflow-hidden"
                >
                    <div className="absolute top-0 right-0 p-2">
                        <ShieldCheckIcon className="w-5 h-5 text-stage-gold opacity-50" />
                    </div>
                    <div className="w-20 h-20 rounded-full bg-stage-gold/10 border border-stage-gold/30 flex items-center justify-center mb-2 group-hover:shadow-[0_0_30px_rgba(252,211,77,0.2)] transition-all">
                        <SparklesIcon className="w-8 h-8 text-stage-gold" />
                    </div>
                    <div className="text-center">
                        <h2 className="text-2xl font-display text-stage-gold">Director</h2>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">老師 / 管理員</p>
                    </div>
                    <div className="mt-4 px-4 py-1 rounded-full border border-stage-gold/30 text-[9px] text-stage-gold uppercase tracking-wider group-hover:bg-stage-gold/10">
                        Full Admin Access
                    </div>
                </button>
            </div>
            
            <p className="fixed bottom-6 text-[9px] text-gray-600 uppercase tracking-widest">
                Smart Roll Call System v3.0 (Cloud Sync)
            </p>
        </div>
      );
  }

  // 2. Student Mode View
  if (userRole === 'student' && !testModeData) {
      return (
        <div className="relative w-full h-full">
            <StudentCheckInView 
                classrooms={classrooms}
                onBack={() => setUserRole(null)}
                // When student finishes check-in, we send P2P data instead of saving locally (handled in View now)
                onCheckInComplete={(name, lat, lng, addr, alt, acc, attempts) => {
                    // Send to teacher if connected
                    if (peerService.getStatus() === 'connected') {
                        peerService.sendData({
                            type: 'CHECK_IN',
                            payload: { n: name, t: Date.now(), l: {lat, lng, altitude: alt, accuracy: acc}, add: addr, a: attempts }
                        });
                        return true; // Indicate send success
                    } else {
                        // Fallback to local
                        handleInternalCheckIn(name, lat, lng, addr, alt, acc, attempts);
                        return false;
                    }
                }}
                p2pStatus={p2pStatus}
            />
        </div>
      );
  }

  // 3. Test Mode (Simulation)
  if (testModeData) {
      return (
          <StudentCheckInView 
             classrooms={classrooms}
             targetLat={testModeData.lat}
             targetLng={testModeData.lng}
             className={testModeData.cls}
             onExit={() => setTestModeData(null)}
             onCheckInComplete={handleInternalCheckIn}
          />
      );
  }

  // 4. Teacher/Admin Mode
  const activeClassroom = classrooms.find(c => c.id === activeClassId);

  return (
    <div className="w-full min-h-screen bg-stage-900 text-white overflow-hidden relative selection:bg-stage-accent selection:text-black perspective-container">
      {/* Admin Badge */}
      <div className="fixed top-4 left-6 z-50 px-3 py-1 glass-stage rounded-full border border-stage-gold/30 flex items-center gap-2 shadow-[0_0_15px_rgba(252,211,77,0.1)]">
          <div className={`w-2 h-2 rounded-full ${p2pStatus === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`}></div>
          <span className="text-[9px] text-stage-gold font-bold uppercase tracking-wider">
              {p2pStatus === 'connected' ? 'Live Room Active' : 'Director Access'}
          </span>
      </div>

      <button onClick={() => { peerService.destroy(); setUserRole(null); }} className="fixed top-4 right-6 z-50 px-3 py-1 text-[10px] text-gray-400 hover:text-white uppercase tracking-widest border border-transparent hover:border-white/20 rounded-full transition-all">
          LOGOUT
      </button>
      
      {/* Global Stage Lights */}
      <div className="fixed inset-0 pointer-events-none z-0">
         <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[80%] bg-blue-500/10 rounded-full blur-[100px] animate-spotlight-1 mix-blend-screen"></div>
         <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[80%] bg-purple-500/10 rounded-full blur-[100px] animate-spotlight-2 mix-blend-screen"></div>
         <div className="beam animate-spotlight-1" style={{ left: '10%', animationDelay: '-2s' }}></div>
         <div className="beam animate-spotlight-2" style={{ left: '40%', animationDelay: '-5s' }}></div>
      </div>

      <div className="relative z-10 h-full">
        {activeClassroom ? (
            <AttendanceView 
            classroom={activeClassroom}
            onBack={() => { setActiveClassId(null); peerService.destroy(); setP2PStatus('disconnected'); }}
            onSaveSession={handleSaveSession}
            onTestMode={(lat, lng, cls) => setTestModeData({ lat, lng, cls })}
            onKioskMode={() => setUserRole('student')}
            p2pStatus={p2pStatus}
            />
        ) : (
            <HomeView 
            classrooms={classrooms}
            onCreateClass={handleCreateClass}
            onSelectClass={(cls) => setActiveClassId(cls.id)}
            onDeleteClass={handleDeleteClass}
            onAddStudents={handleAddStudents}
            />
        )}
      </div>
    </div>
  );
};

export default App;