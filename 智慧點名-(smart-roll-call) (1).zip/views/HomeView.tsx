import React, { useState, useRef } from 'react';
import { Classroom, Student, LocationConfig } from '../types';
import { PlusIcon, UserIcon, TrashIcon, SparklesIcon, CameraIcon, QuestionMarkIcon, ArrowRightIcon, MapPinIcon, LinkIcon } from '../components/Icon';
import { parseStudentList, parseStudentListFromImage, parseScheduleFromImage } from '../services/geminiService';
import { fileToGenerativePart } from '../utils/file';

interface HomeViewProps {
  classrooms: Classroom[];
  onCreateClass: (
      name: string, 
      subject: string, 
      schedule?: {dayOfWeek: number, startTime: string, endTime: string}, 
      locationConfig?: LocationConfig
  ) => void;
  onSelectClass: (classroom: Classroom) => void;
  onDeleteClass: (id: string) => void;
  onAddStudents: (classId: string, students: Student[]) => void;
}

const HomeView: React.FC<HomeViewProps> = ({ classrooms, onCreateClass, onSelectClass, onDeleteClass, onAddStudents }) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showStudentModal, setShowStudentModal] = useState<string | null>(null);
  const [showHelpModal, setShowHelpModal] = useState(false);
  
  // New Class Form State
  const [newClassName, setNewClassName] = useState('');
  const [newClassSubject, setNewClassSubject] = useState('');
  const [dayOfWeek, setDayOfWeek] = useState<number>(new Date().getDay());
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('12:00');

  // Location Form State
  const [fixedLocation, setFixedLocation] = useState<LocationConfig | undefined>(undefined);
  const [isLocating, setIsLocating] = useState(false);
  
  const [rawStudentText, setRawStudentText] = useState('');
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  
  const scheduleInputRef = useRef<HTMLInputElement>(null);
  const rosterInputRef = useRef<HTMLInputElement>(null);

  const handleCreate = () => {
    if (newClassName) {
      onCreateClass(
          newClassName, 
          newClassSubject, 
          { dayOfWeek, startTime, endTime },
          fixedLocation
      );
      setNewClassName('');
      setNewClassSubject('');
      setFixedLocation(undefined);
      setShowCreateModal(false);
    }
  };

  const handleSetCurrentLocation = () => {
      if (!navigator.geolocation) {
          alert('GPS not supported');
          return;
      }
      setIsLocating(true);
      navigator.geolocation.getCurrentPosition(
          (pos) => {
              setFixedLocation(prev => ({
                  ...prev,
                  lat: pos.coords.latitude,
                  lng: pos.coords.longitude,
                  floor: prev?.floor || '',
                  radius: 50
              }));
              setIsLocating(false);
          },
          (err) => {
              console.error(err);
              alert('Unable to retrieve location');
              setIsLocating(false);
          },
          { enableHighAccuracy: true }
      );
  };

  const handleAiImport = async () => {
    if (!rawStudentText.trim()) return;
    setIsProcessingAI(true);
    const names = await parseStudentList(rawStudentText);
    const students: Student[] = names.map(name => ({ id: crypto.randomUUID(), name }));
    if (showStudentModal) {
        onAddStudents(showStudentModal, students);
        setRawStudentText('');
        setShowStudentModal(null);
    }
    setIsProcessingAI(false);
  };

  const handleScheduleImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setIsProcessingAI(true);
    try {
        const imagePart = await fileToGenerativePart(file);
        const courses = await parseScheduleFromImage(imagePart);
        if (courses.length > 0) {
            courses.forEach(c => onCreateClass(c.name, c.subject, undefined));
        } else {
            alert("未識別到課程，請重試。");
        }
    } catch (error) {
        console.error(error);
        alert("分析失敗");
    } finally {
        setIsProcessingAI(false);
        if (scheduleInputRef.current) scheduleInputRef.current.value = '';
    }
  };

  const handleRosterImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
     if (!e.target.files || e.target.files.length === 0) return;
     const file = e.target.files[0];
     setIsProcessingAI(true);
     try {
        const imagePart = await fileToGenerativePart(file);
        const names = await parseStudentListFromImage(imagePart);
        if (names.length > 0) {
            setRawStudentText(prev => (prev ? prev + ', ' : '') + names.join(', '));
        } else {
            alert("未識別到姓名，請重試。");
        }
     } catch (error) {
         console.error(error);
         alert("分析失敗");
     } finally {
         setIsProcessingAI(false);
         if (rosterInputRef.current) rosterInputRef.current.value = '';
     }
  };
  
  const handleShareApp = () => {
      const url = window.location.href;
      if (navigator.share) {
          navigator.share({
              title: 'Smart Roll Call',
              text: 'Join the smart classroom system',
              url: url
          });
      } else {
          navigator.clipboard.writeText(url);
          alert('Link copied! Share it with students.');
      }
  };

  const getDayName = (day: number) => ['週日', '週一', '週二', '週三', '週四', '週五', '週六'][day];

  return (
    <div className="min-h-screen pb-24 relative overflow-x-hidden">
      <input type="file" accept="image/*" capture="environment" className="hidden" ref={scheduleInputRef} onChange={handleScheduleImage} />

      {/* Header with Glow */}
      <header className="pt-16 pb-8 px-8 sticky top-0 z-20 transition-all duration-300">
        {/* Backdrop filter hack for sticky header */}
        <div className="absolute inset-0 bg-stage-900/50 backdrop-blur-md -z-10 border-b border-white/5"></div>
        
        <div className="flex justify-between items-end relative">
          <div className="animate-fade-in">
            <p className="text-stage-accent text-[10px] font-bold tracking-[0.2em] uppercase mb-1 drop-shadow-[0_0_8px_rgba(56,189,248,0.5)]">
                Stage Control
            </p>
            <h1 className="text-4xl font-display font-medium text-white tracking-tight drop-shadow-lg">
                Productions
                <span className="text-xl font-sans font-normal text-gray-400 ml-3">演出列表</span>
            </h1>
          </div>
          <div className="flex gap-2">
            <button 
                onClick={handleShareApp}
                className="w-12 h-12 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all duration-300 border border-white/10 backdrop-blur-md"
                title="Share App Link"
            >
                <LinkIcon className="w-5 h-5" />
            </button>
            <button 
                onClick={() => setShowHelpModal(true)}
                className="w-12 h-12 rounded-full flex items-center justify-center text-stage-gold/80 hover:text-stage-gold hover:bg-stage-gold/10 transition-all duration-300 border border-stage-gold/20 backdrop-blur-md shadow-[0_0_10px_rgba(252,211,77,0.2)]"
            >
                <QuestionMarkIcon className="w-5 h-5" />
            </button>
            <button 
                onClick={() => scheduleInputRef.current?.click()}
                disabled={isProcessingAI}
                className="w-12 h-12 rounded-full flex items-center justify-center text-white/80 hover:text-white hover:bg-white/10 transition-all duration-300 border border-white/10 backdrop-blur-md shadow-[0_0_15px_rgba(0,0,0,0.5)]"
            >
                {isProcessingAI ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"/> : <CameraIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="px-6 space-y-6 pt-4">
        {classrooms.length === 0 && (
            <div className="flex flex-col items-center justify-center py-32 text-center animate-fade-in relative">
                {/* Empty State Spotlight */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-stage-gold/10 rounded-full blur-[80px]"></div>
                
                <div className="relative w-24 h-24 rounded-full glass-stage flex items-center justify-center mb-6 animate-float">
                    <SparklesIcon className="w-10 h-10 text-stage-gold" />
                </div>
                <h3 className="text-2xl font-display text-white mb-2 drop-shadow-md">The Stage is Empty</h3>
                <p className="text-gray-400 text-sm max-w-xs mx-auto mb-1">
                    舞台尚未準備就緒
                </p>
                <p className="text-xs text-gray-500">
                    點擊 + 按鈕開始製作
                </p>
            </div>
        )}

        {classrooms.map((cls, index) => (
          <div 
            key={cls.id} 
            onClick={() => onSelectClass(cls)}
            className="group card-3d glass-stage rounded-2xl p-6 cursor-pointer relative overflow-hidden animate-fade-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            {/* Card internal glow */}
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-white/5 rounded-full blur-3xl group-hover:bg-stage-accent/20 transition-colors duration-500"></div>

            <div className="flex justify-between items-start mb-4 relative z-10">
                <div>
                    <span className="inline-block text-stage-accent/80 text-[10px] font-bold tracking-widest uppercase mb-2 border border-stage-accent/20 px-2 py-0.5 rounded shadow-[0_0_10px_rgba(56,189,248,0.1)]">
                        {cls.subject || 'Live Event'}
                    </span>
                    <h3 className="text-2xl font-display font-bold text-white group-hover:text-stage-accent transition-colors drop-shadow-md">
                        {cls.name}
                    </h3>
                    {cls.schedule && (
                         <div className="text-[10px] text-gray-500 mt-1 font-mono uppercase tracking-tight">
                            {getDayName(cls.schedule.dayOfWeek)} • {cls.schedule.startTime} - {cls.schedule.endTime}
                         </div>
                    )}
                    {cls.defaultLocation?.floor && (
                        <div className="text-[10px] text-stage-gold/80 mt-1 font-bold uppercase tracking-wide flex items-center gap-1">
                            <MapPinIcon className="w-3 h-3" />
                            {cls.defaultLocation.floor}
                        </div>
                    )}
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-4 group-hover:translate-x-0">
                    <button 
                        onClick={(e) => { e.stopPropagation(); setShowStudentModal(cls.id); }}
                        className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    >
                        <UserIcon className="w-5 h-5" />
                    </button>
                    <button 
                        onClick={(e) => { e.stopPropagation(); if(confirm('確定刪除?')) onDeleteClass(cls.id); }}
                        className="p-2 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                    >
                        <TrashIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>

            <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/10 relative z-10">
                <div className="flex items-center gap-3">
                   <div className="flex -space-x-3 pl-1">
                        {cls.students.slice(0, 4).map((s) => (
                            <div key={s.id} className="w-8 h-8 rounded-full bg-stage-800 border border-gray-600 flex items-center justify-center text-[10px] font-bold text-gray-300 shadow-lg">
                                {s.name.charAt(0)}
                            </div>
                        ))}
                   </div>
                   <span className="text-xs text-gray-400 font-medium">
                        {cls.students.length} Performers
                   </span>
                </div>
                <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center text-gray-400 group-hover:border-stage-accent group-hover:text-stage-accent group-hover:shadow-[0_0_10px_rgba(56,189,248,0.4)] transition-all">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                        <path fillRule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clipRule="evenodd" />
                    </svg>
                </div>
            </div>
          </div>
        ))}
      </div>

      {/* Floating Add Button */}
      <div className="fixed bottom-8 right-8 z-30 perspective-container">
          <button 
            onClick={() => setShowCreateModal(true)}
            className="w-16 h-16 bg-white text-black rounded-full shadow-[0_0_30px_rgba(255,255,255,0.3)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all duration-300 card-3d"
          >
            <PlusIcon className="w-7 h-7" />
          </button>
      </div>

      {/* Create Class Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-lg z-50 flex items-center justify-center p-6 animate-fade-in overflow-y-auto">
            <div className="glass-stage w-full max-w-sm rounded-2xl p-8 relative overflow-hidden my-auto">
                 {/* Modal Lighting */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-stage-accent to-transparent"></div>
                
                <h3 className="text-2xl font-display text-white mb-1">New Production</h3>
                <p className="text-gray-400 text-xs mb-6 uppercase tracking-widest">Setup stage details</p>
                <div className="space-y-5">
                    <div className="group">
                        <label className="block text-stage-accent text-[10px] font-bold mb-2 uppercase tracking-widest">Title / 劇目名稱</label>
                        <input 
                            className="w-full bg-transparent border-b border-white/20 focus:border-stage-accent text-white pb-2 focus:outline-none transition-all text-lg font-display placeholder-white/20"
                            placeholder="e.g. Autumn Gala"
                            value={newClassName}
                            onChange={e => setNewClassName(e.target.value)}
                            autoFocus
                        />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                         <div className="group">
                            <label className="block text-stage-accent text-[10px] font-bold mb-2 uppercase tracking-widest">Start</label>
                            <input 
                                type="time"
                                className="w-full bg-transparent border-b border-white/20 focus:border-stage-accent text-white pb-2 focus:outline-none"
                                value={startTime}
                                onChange={e => setStartTime(e.target.value)}
                            />
                        </div>
                        <div className="group">
                            <label className="block text-stage-accent text-[10px] font-bold mb-2 uppercase tracking-widest">End</label>
                            <input 
                                type="time"
                                className="w-full bg-transparent border-b border-white/20 focus:border-stage-accent text-white pb-2 focus:outline-none"
                                value={endTime}
                                onChange={e => setEndTime(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className="group">
                         <label className="block text-stage-accent text-[10px] font-bold mb-2 uppercase tracking-widest">Day of Week</label>
                         <div className="flex justify-between">
                            {[1,2,3,4,5,6,0].map(d => (
                                <button
                                    key={d}
                                    onClick={() => setDayOfWeek(d)}
                                    className={`w-8 h-8 rounded-full text-[10px] font-bold transition-all ${dayOfWeek === d ? 'bg-stage-gold text-black scale-110 shadow-lg' : 'bg-white/5 text-gray-500 hover:text-white'}`}
                                >
                                    {['日','一','二','三','四','五','六'][d]}
                                </button>
                            ))}
                         </div>
                    </div>

                    {/* Location Settings */}
                    <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3">
                        <label className="flex items-center gap-2 text-stage-gold text-[10px] font-bold uppercase tracking-widest">
                            <MapPinIcon className="w-3 h-3" /> 
                            Stage Location (Optional)
                        </label>
                        
                        <div className="flex gap-2">
                             <input 
                                className="flex-1 bg-black/30 border border-white/10 rounded px-3 py-2 text-xs text-white focus:border-stage-gold focus:outline-none"
                                placeholder="Floor / Room (e.g. 3F, Room A)"
                                value={fixedLocation?.floor || ''}
                                onChange={e => setFixedLocation(prev => ({ 
                                    lat: prev?.lat || 0, 
                                    lng: prev?.lng || 0,
                                    floor: e.target.value 
                                }))}
                             />
                             <button 
                                onClick={handleSetCurrentLocation}
                                className="bg-stage-gold/20 hover:bg-stage-gold/30 text-stage-gold px-3 py-2 rounded text-[10px] font-bold uppercase tracking-wide border border-stage-gold/30"
                             >
                                {isLocating ? '...' : 'Get GPS'}
                             </button>
                        </div>
                        {fixedLocation && fixedLocation.lat !== 0 && (
                            <div className="text-[9px] text-green-400 font-mono">
                                Coordinates Locked: {fixedLocation.lat.toFixed(4)}, {fixedLocation.lng.toFixed(4)}
                            </div>
                        )}
                        <p className="text-[9px] text-gray-500">
                            * 設定固定座標後，老師無需到場也能發起點名。<br/>
                            * 建議輸入樓層資訊供學生確認。
                        </p>
                    </div>

                    <div className="group">
                        <label className="block text-stage-accent text-[10px] font-bold mb-2 uppercase tracking-widest">Details / 備註</label>
                        <input 
                            className="w-full bg-transparent border-b border-white/20 focus:border-stage-accent text-white pb-2 focus:outline-none transition-all text-base placeholder-white/20"
                            placeholder="e.g. Main Hall"
                            value={newClassSubject}
                            onChange={e => setNewClassSubject(e.target.value)}
                        />
                    </div>
                </div>
                <div className="flex gap-4 mt-8">
                    <button onClick={() => setShowCreateModal(false)} className="flex-1 py-3 text-gray-500 text-xs font-bold hover:text-white transition-colors tracking-widest uppercase">
                        Cancel
                    </button>
                    <button onClick={handleCreate} disabled={!newClassName} className="flex-1 py-3 bg-white text-black rounded-lg text-xs font-bold tracking-widest hover:bg-gray-200 transition-all disabled:opacity-50 uppercase shadow-[0_0_15px_rgba(255,255,255,0.2)]">
                        Create
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Add Student Modal */}
      {showStudentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-lg z-50 flex items-center justify-center p-4">
            <input type="file" accept="image/*" capture="environment" className="hidden" ref={rosterInputRef} onChange={handleRosterImage} />
            <div className="glass-stage w-full max-w-md rounded-2xl p-8 animate-fade-in relative">
                <div className="absolute -top-10 -left-10 w-32 h-32 bg-stage-gold/20 rounded-full blur-[40px]"></div>

                <h3 className="text-xl font-display text-white mb-2 flex items-center gap-2 relative z-10">
                    <SparklesIcon className="w-5 h-5 text-stage-gold"/> Cast List
                </h3>
                <p className="text-xs text-gray-400 mb-6 uppercase tracking-wider relative z-10">Import performers / 匯入名單</p>
                
                <div className="relative group z-10">
                    <textarea 
                        className="w-full h-40 p-4 bg-black/30 rounded-xl border border-white/10 focus:border-stage-gold focus:outline-none text-gray-200 resize-none transition-all font-mono text-sm placeholder-gray-600 shadow-inner"
                        placeholder="Paste names here..."
                        value={rawStudentText}
                        onChange={e => setRawStudentText(e.target.value)}
                    />
                    <button 
                        onClick={() => rosterInputRef.current?.click()}
                        disabled={isProcessingAI}
                        className="absolute bottom-4 right-4 w-9 h-9 bg-stage-800 rounded-lg border border-white/20 text-gray-400 hover:text-stage-gold hover:border-stage-gold transition-all flex items-center justify-center shadow-lg"
                    >
                        {isProcessingAI ? <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"/> : <CameraIcon className="w-5 h-5" />}
                    </button>
                </div>
                
                <div className="flex gap-4 mt-8 relative z-10">
                    <button onClick={() => setShowStudentModal(null)} className="flex-1 py-3 text-gray-500 font-bold hover:text-white transition-colors text-xs tracking-widest uppercase">
                        Cancel
                    </button>
                    <button onClick={handleAiImport} disabled={!rawStudentText || isProcessingAI} className="flex-1 py-3 bg-gradient-to-r from-stage-gold to-yellow-600 text-black rounded-lg font-bold hover:brightness-110 transition-all disabled:opacity-50 text-xs tracking-widest uppercase shadow-[0_0_20px_rgba(252,211,77,0.3)]">
                        {isProcessingAI ? 'Processing...' : 'Confirm'}
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Help Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[60] flex items-center justify-center p-6 animate-fade-in" onClick={() => setShowHelpModal(false)}>
            <div className="w-full max-w-lg space-y-8" onClick={e => e.stopPropagation()}>
                <div className="text-center">
                     <h2 className="text-3xl font-display text-white mb-2">How to Use</h2>
                     <p className="text-stage-accent text-xs tracking-[0.2em] uppercase">使用指南</p>
                </div>
                
                <div className="space-y-4">
                    <div className="glass-stage p-6 rounded-xl flex items-center gap-4 border-l-4 border-stage-gold relative overflow-hidden">
                         <div className="w-10 h-10 rounded-full bg-stage-gold text-black flex items-center justify-center font-bold font-display text-lg relative z-10">1</div>
                         <div className="flex-1 relative z-10">
                             <h3 className="text-white font-bold text-sm mb-1">Create & Enter</h3>
                             <p className="text-gray-400 text-xs">建立課程並設定時間，系統將自動判斷。</p>
                         </div>
                    </div>

                     <div className="flex justify-center text-white/20">
                        <ArrowRightIcon className="w-6 h-6 rotate-90" />
                     </div>

                    <div className="glass-stage p-6 rounded-xl flex items-center gap-4 border-l-4 border-stage-accent relative overflow-hidden">
                         <div className="w-10 h-10 rounded-full bg-stage-accent text-black flex items-center justify-center font-bold font-display text-lg relative z-10">2</div>
                         <div className="flex-1 relative z-10">
                             <h3 className="text-white font-bold text-sm mb-1">Strict Check-in</h3>
                             <p className="text-gray-400 text-xs">學生僅有兩次機會打卡，位置錯誤即鎖定。</p>
                         </div>
                    </div>

                    <div className="glass-stage p-6 rounded-xl flex items-center gap-4 border-l-4 border-red-500 relative overflow-hidden">
                         <div className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center font-bold font-display text-lg relative z-10">3</div>
                         <div className="flex-1 relative z-10">
                             <h3 className="text-white font-bold text-sm mb-1">Live Monitor</h3>
                             <p className="text-gray-400 text-xs">打卡後系統持續監控，離席將顯示警告。</p>
                         </div>
                    </div>
                </div>

                <div className="text-center pt-4">
                    <button onClick={() => setShowHelpModal(false)} className="text-white/50 hover:text-white text-xs uppercase tracking-widest border-b border-transparent hover:border-white pb-1 transition-all">
                        Close Guide
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default HomeView;