import React, { useState, useEffect, useRef } from 'react';
import { MapPinIcon, CheckIcon, XMarkIcon, ShieldCheckIcon, ArrowRightIcon, UserIcon, ChevronLeftIcon, PlusIcon, SparklesIcon } from '../components/Icon';
import { calculateDistance } from '../utils/geo';
import { getAddressFromCoordinates } from '../services/geminiService';
import { Classroom, AttendanceRecord, AttendanceStatus } from '../types';

interface StudentCheckInViewProps {
  classrooms?: Classroom[]; 
  targetLat?: number;
  targetLng?: number;
  className?: string; 
  onExit?: () => void;
  onBack?: () => void;
  // UPDATED SIGNATURE: Return true/false if p2p send worked
  onCheckInComplete?: (
      studentName: string, 
      lat: number, 
      lng: number, 
      address: string, 
      altitude?: number | null, 
      accuracy?: number, 
      attempts?: number
  ) => boolean | void;
  p2pStatus?: string; // NEW
}

const StudentCheckInView: React.FC<StudentCheckInViewProps> = ({ 
    classrooms: propClassrooms,
    targetLat: propLat, 
    targetLng: propLng, 
    className: propClassName, 
    onExit,
    onBack,
    onCheckInComplete,
    p2pStatus
}) => {
  // Flow: Name -> (Auto-Detect) -> Locating (Scanning) -> Success -> Monitoring
  const [step, setStep] = useState<'name-input' | 'locating' | 'success' | 'fail' | 'locked'>('name-input');
  
  const [studentName, setStudentName] = useState('');
  const [selectedClass, setSelectedClass] = useState<Classroom | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [distance, setDistance] = useState<number | null>(null);
  
  // Added altitude to state
  const [capturedLoc, setCapturedLoc] = useState<{lat: number, lng: number, accuracy: number, altitude: number | null, altitudeAccuracy: number | null} | null>(null);
  const [capturedAddress, setCapturedAddress] = useState<string>('定位地址中...');
  const [attempts, setAttempts] = useState(0);
  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [directorPin, setDirectorPin] = useState('');
  
  // Admin/Debug Mode State (Hidden by default)
  const [showDebugInfo, setShowDebugInfo] = useState(false);
  
  // New State for Precision Scanning
  const [scanProgress, setScanProgress] = useState(0); // 0 to 100
  const [sampleCount, setSampleCount] = useState(0);
  const [currentAccuracy, setCurrentAccuracy] = useState<number | null>(null);

  // Monitoring State
  const [isTruant, setIsTruant] = useState(false);
  const [sentToDirector, setSentToDirector] = useState(false); // Track p2p send status
  
  const watchIdRef = useRef<number | null>(null);
  const scanIntervalRef = useRef<any>(null);
  const scanWatchIdRef = useRef<number | null>(null);
  const samplesRef = useRef<GeolocationCoordinates[]>([]); // Buffer for smoothing
  
  // Use props if available (Test Mode), otherwise parse URL params
  const query = new URLSearchParams(window.location.search);
  const targetLat = propLat ?? parseFloat(query.get('lat') || '0');
  const targetLng = propLng ?? parseFloat(query.get('lng') || '0');
  const propClass = propClassName ?? query.get('cls');

  const MAX_ATTEMPTS = 2;
  const MONITOR_THRESHOLD_M = 200; // 200m radius
  
  // Tuning for "Robust Inverse-Variance Weighting"
  const MAX_SCAN_DURATION_MS = 10000; // 10 seconds max
  const EARLY_EXIT_ACCURACY_M = 15; // 15m is good enough for web
  const MIN_SAMPLES_FOR_CALCULATION = 2; // Reduced to ensure we can calculate faster

  // Handle Navigation
  const handleNavBack = () => {
      if (onBack) onBack();
      else if (onExit) onExit();
      else window.history.back();
  };
  
  const resetForNextStudent = () => {
      setStudentName('');
      setStep('name-input');
      setIsTruant(false);
      setAttempts(0);
      setScanProgress(0);
      setErrorMsg('');
      setCapturedLoc(null);
      setSentToDirector(false);
  };

  useEffect(() => {
    // Optional: Load attempt count from local storage
  }, []);

  // Cleanup scan on unmount or step change
  useEffect(() => {
      return () => {
          if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
          if (scanWatchIdRef.current !== null) navigator.geolocation.clearWatch(scanWatchIdRef.current);
      };
  }, []);

  const getStorageKey = (name: string) => {
      const date = new Date().toISOString().split('T')[0];
      const cleanName = name.trim().replace(/\s/g, '');
      return `checkin_attempts_${date}_${cleanName}`;
  };

  const checkLockout = (name: string) => {
      const key = getStorageKey(name);
      const savedAttempts = parseInt(localStorage.getItem(key) || '0');
      setAttempts(savedAttempts);
      if (savedAttempts >= MAX_ATTEMPTS) {
          setStep('locked');
          return true;
      }
      return false;
  };

  const incrementAttempts = (name: string) => {
      const key = getStorageKey(name);
      const newCount = attempts + 1;
      setAttempts(newCount);
      localStorage.setItem(key, newCount.toString());
      if (newCount >= MAX_ATTEMPTS) {
          setStep('locked');
      }
  };

  const resetAttempts = () => {
      if (directorPin === '0000') { // Default PIN
          const key = getStorageKey(studentName);
          localStorage.removeItem(key);
          setAttempts(0);
          setShowUnlockModal(false);
          setDirectorPin('');
          setStep('name-input');
          alert('Director Override: Access Granted.');
      } else {
          alert('Invalid PIN.');
      }
  };

  const handleNameSubmit = () => {
      if (!studentName.trim()) return;
      if (checkLockout(studentName)) return;

      // 1. Load Data
      let classrooms: Classroom[] = propClassrooms || [];
      if (classrooms.length === 0) {
          const saved = localStorage.getItem('smart-roll-call-data');
          if (saved) classrooms = JSON.parse(saved);
      }

      if (classrooms.length === 0 && !onCheckInComplete) {
          setErrorMsg('系統初始化中或是資料庫為空，請稍後再試或通知老師。');
          return;
      }
      
      // 2. Strict Auto-Detection
      const cleanInput = studentName.trim().replace(/\s/g, '');
      
      const studentClasses = classrooms.filter(cls => {
          return cls.students.some(s => {
              const cleanName = s.name.replace(/\s/g, '');
              return cleanName.includes(cleanInput) || cleanInput.includes(cleanName);
          });
      });

      if (studentClasses.length === 0) {
          setErrorMsg('查無此人，請確認姓名。');
          return;
      }

      // Priority 1: Match specifically requested class (Test/QR Mode)
      let activeClass = propClass ? studentClasses.find(c => c.name === propClass) : undefined;
      
      // Priority 2: Match Time (If precise time logic is desired, uncomment above)
      // For now, to solve "data won't come in", we assume the first matching class is correct
      if (!activeClass) {
           activeClass = studentClasses[0];
      }

      if (!activeClass) {
          setErrorMsg('目前非您的上課時段 (No Active Class Found)');
          return;
      }

      setSelectedClass(activeClass);
      startPrecisionScan(activeClass.name);
  };
  
  const performDataUpdate = (
      clsName: string, 
      lat: number, 
      lng: number, 
      address: string, 
      altitude: number | null, 
      accuracy: number
  ) => {
      const attemptsUsed = attempts + 1;

      if (onCheckInComplete) {
          const result = onCheckInComplete(studentName, lat, lng, address, altitude, accuracy, attemptsUsed);
          if (result === true) {
              setSentToDirector(true);
          } else {
              setSentToDirector(false);
          }
          return;
      }
  };

  /**
   * ROBUST INVERSE-VARIANCE WEIGHTING ALGORITHM
   */
  const startPrecisionScan = (clsName: string) => {
    setStep('locating');
    setErrorMsg('');
    setScanProgress(0);
    setSampleCount(0);
    samplesRef.current = [];

    if (!navigator.geolocation) { 
        setStep('fail'); 
        setErrorMsg('您的裝置不支援 GPS'); 
        return; 
    }

    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    if (scanWatchIdRef.current !== null) navigator.geolocation.clearWatch(scanWatchIdRef.current);

    let scanStartTime = Date.now();
    let isFinished = false;

    const calculateWeightedPosition = (samples: GeolocationCoordinates[]) => {
        if (samples.length === 0) return null;

        // Level 1: Strict (Outdoors)
        let validSamples = samples.filter(s => s.accuracy <= 60);

        // Level 2: Relaxed (Indoors/Windows)
        if (validSamples.length === 0) {
             validSamples = samples.filter(s => s.accuracy <= 200);
        }

        // Level 3: Desperation (Just take the best one we have)
        if (validSamples.length === 0) {
            const bestSample = [...samples].sort((a, b) => a.accuracy - b.accuracy)[0];
            return {
                latitude: bestSample.latitude,
                longitude: bestSample.longitude,
                accuracy: bestSample.accuracy,
                altitude: bestSample.altitude,
                altitudeAccuracy: bestSample.altitudeAccuracy
            };
        }

        // Standard Weighted Calculation
        let totalLatWeight = 0;
        let totalLngWeight = 0;
        let totalWeight = 0;
        let minAccuracy = 9999;
        
        let totalAltWeight = 0;
        let totalAlt = 0;
        let avgAltAcc = 0;
        let altCount = 0;

        for (const s of validSamples) {
            if (s.accuracy < minAccuracy) minAccuracy = s.accuracy;
            const weight = 1 / Math.pow(Math.max(s.accuracy, 1), 2);
            
            totalLatWeight += s.latitude * weight;
            totalLngWeight += s.longitude * weight;
            totalWeight += weight;

            if (s.altitude !== null) {
                const altAcc = s.altitudeAccuracy || 20;
                const altWeight = 1 / Math.pow(Math.max(altAcc, 1), 2);
                
                totalAlt += s.altitude * altWeight;
                totalAltWeight += altWeight;
                avgAltAcc += altAcc;
                altCount++;
            }
        }

        return {
            latitude: totalLatWeight / totalWeight,
            longitude: totalLngWeight / totalWeight,
            accuracy: minAccuracy,
            altitude: totalAltWeight > 0 ? totalAlt / totalAltWeight : null,
            altitudeAccuracy: altCount > 0 ? avgAltAcc / altCount : null
        };
    };

    const stopScan = () => {
        isFinished = true;
        if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
        if (scanWatchIdRef.current !== null) navigator.geolocation.clearWatch(scanWatchIdRef.current);
    };

    const finishSuccess = () => {
        stopScan();
        const weightedPos = calculateWeightedPosition(samplesRef.current);
        
        if (weightedPos) {
             finalizeCheckIn(clsName, weightedPos);
        } else {
             finishFail();
        }
    };

    const finishFail = () => {
        stopScan();
        setStep('fail');
        setErrorMsg('無法取得有效的 GPS 訊號，請移動到空曠處重試。');
    };

    const onPositionUpdate = (coords: GeolocationCoordinates) => {
        if (isFinished) return;
        samplesRef.current.push(coords);
        setSampleCount(samplesRef.current.length);
        setCurrentAccuracy(coords.accuracy);

        if (samplesRef.current.length >= MIN_SAMPLES_FOR_CALCULATION && coords.accuracy <= EARLY_EXIT_ACCURACY_M) {
            setScanProgress(100);
            finishSuccess();
        }
    };

    navigator.geolocation.getCurrentPosition(
        (pos) => onPositionUpdate(pos.coords),
        (err) => console.warn("Quick fix failed", err),
        { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
    );

    scanWatchIdRef.current = navigator.geolocation.watchPosition(
        (position) => onPositionUpdate(position.coords),
        (err) => {
            console.warn("GPS Watch Warning:", err);
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 }
    );

    scanIntervalRef.current = setInterval(async () => {
        if (isFinished) return;
        const elapsed = Date.now() - scanStartTime;
        const progress = Math.min((elapsed / MAX_SCAN_DURATION_MS) * 100, 100);
        setScanProgress(progress);

        if (elapsed >= MAX_SCAN_DURATION_MS) {
            if (samplesRef.current.length > 0) {
                finishSuccess();
            } else {
                finishFail();
            }
        }
    }, 100);
  };

  const finalizeCheckIn = async (clsName: string, coords: {latitude: number, longitude: number, accuracy: number, altitude: number | null, altitudeAccuracy: number | null}) => {
    const { latitude, longitude, accuracy, altitude, altitudeAccuracy } = coords;
    setCapturedLoc({ lat: latitude, lng: longitude, accuracy, altitude, altitudeAccuracy });

    let passed = false;
    let dist = 0;

    if (targetLat === 0 && targetLng === 0) {
        passed = true; 
    } else {
        dist = calculateDistance(latitude, longitude, targetLat, targetLng);
        setDistance(Math.round(dist));
        
        const allowedRadius = selectedClass?.defaultLocation?.radius || 100;
        if (dist <= allowedRadius) passed = true; 
    }

    if (passed) {
        const address = await getAddressFromCoordinates(latitude, longitude);
        setCapturedAddress(address);
        performDataUpdate(clsName, latitude, longitude, address, altitude, accuracy); 
        setStep('success');
    } else {
         incrementAttempts(studentName);
         setStep('fail'); 
         setErrorMsg(`位置不符 (距離 ${Math.round(dist)}m)`); 
    }
  };

  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    if (step === 'success') {
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }
  }, [step]);

  // Truancy Monitor
  useEffect(() => {
    if (step === 'success' && navigator.geolocation && targetLat !== 0) {
        watchIdRef.current = navigator.geolocation.watchPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const dist = calculateDistance(latitude, longitude, targetLat, targetLng);
                if (dist > MONITOR_THRESHOLD_M) {
                    setIsTruant(true);
                } else {
                    setIsTruant(false);
                }
            }, 
            (err) => console.error("Monitor error", err),
            { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
        );
    }
    return () => {
        if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
    };
  }, [step, targetLat, targetLng]);

  const Header = () => (
      <div className="absolute top-0 left-0 p-4 z-50">
          <button onClick={handleNavBack} className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors bg-black/20 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
              <ChevronLeftIcon className="w-4 h-4" />
              <span className="text-[10px] uppercase tracking-widest font-bold">Home</span>
          </button>
      </div>
  );

  // Render Lockout
  if (step === 'locked') {
      return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8 text-center font-sans relative overflow-hidden">
             <Header />
             <div className="absolute inset-0 bg-red-900/20 animate-pulse"></div>
             <div className="relative z-10 w-24 h-24 rounded-full border-4 border-red-600 flex items-center justify-center mb-6 bg-black/50">
                <ShieldCheckIcon className="w-12 h-12 text-red-600" />
            </div>
            <h1 className="relative z-10 text-3xl font-display font-bold text-white mb-2">ACCESS DENIED</h1>
            <p className="relative z-10 text-red-500 text-xs tracking-[0.2em] uppercase mb-8">帳號已鎖定</p>
            <p className="relative z-10 text-gray-400 text-sm max-w-xs leading-relaxed mb-12">
                您已連續兩次打卡失敗。為了防止作弊，系統已暫停您的權限。請聯繫導演(老師)解鎖。
            </p>
            
            <button 
                onClick={() => setShowUnlockModal(true)}
                className="relative z-10 flex items-center gap-2 text-gray-500 hover:text-white transition-colors text-xs uppercase tracking-widest border border-white/10 px-4 py-2 rounded-full hover:bg-white/10"
            >
                <UserIcon className="w-3 h-3" /> Director Override
            </button>

            {showUnlockModal && (
                <div className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-6">
                    <div className="w-full max-w-xs bg-stage-900 border border-stage-gold/30 p-6 rounded-xl text-center">
                        <h3 className="text-stage-gold font-display text-xl mb-4">Director Override</h3>
                        <input 
                            type="password" 
                            className="w-full bg-black border-b border-white/20 text-center text-white text-2xl tracking-[0.5em] py-2 focus:outline-none focus:border-stage-gold mb-6"
                            placeholder="PIN"
                            value={directorPin}
                            onChange={e => setDirectorPin(e.target.value)}
                        />
                        <div className="flex gap-2">
                             <button onClick={() => {setShowUnlockModal(false); setDirectorPin('');}} className="flex-1 py-3 text-gray-500 text-xs">CANCEL</button>
                             <button onClick={resetAttempts} className="flex-1 py-3 bg-stage-gold text-black font-bold text-xs">UNLOCK</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
      );
  }

  // Render Success (Monitoring)
  if (step === 'success') {
    const estimatedFloor = capturedLoc?.altitude 
        ? Math.max(1, Math.floor(capturedLoc.altitude / 3.5)) 
        : null;

    return (
        <div className={`min-h-screen flex flex-col items-center justify-center p-8 text-center font-sans relative overflow-hidden transition-colors duration-1000 ${isTruant ? 'bg-red-950' : 'bg-black'}`}>
            <Header />
            {isTruant && (
                 <div className="absolute inset-0 border-[20px] border-red-600/50 animate-pulse z-50 pointer-events-none"></div>
            )}
            
            <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-full h-[80%] bg-gradient-to-b ${isTruant ? 'from-red-600/20' : 'from-stage-gold/20'} to-transparent pointer-events-none blur-3xl`}></div>
            
            <div className={`w-20 h-20 rounded-full border-2 ${isTruant ? 'border-red-500 animate-bounce' : 'border-stage-gold'} flex items-center justify-center mb-6 animate-fade-in shadow-[0_0_30px_rgba(252,211,77,0.4)] relative z-10 bg-black/50 backdrop-blur-sm`}>
                {isTruant ? <XMarkIcon className="w-10 h-10 text-red-500" /> : <CheckIcon className="w-10 h-10 text-stage-gold" />}
            </div>
            
            <h1 className="text-2xl font-display font-bold text-white mb-1 animate-fade-in relative z-10">
                {isTruant ? 'OFF STAGE' : 'Check-in Pass'}
            </h1>
            <p className={`${isTruant ? 'text-red-400 font-bold animate-pulse' : 'text-stage-gold'} text-[10px] tracking-[0.3em] uppercase mb-6 animate-fade-in relative z-10`}>
                {isTruant ? '警告：您已離開教室範圍' : '請保持頁面開啟'}
            </p>
            
            <div className="glass-stage w-full max-w-xs p-6 rounded-xl mb-6 animate-fade-in relative z-10 border-t border-white/20">
                {/* Cloud Sync Status */}
                <div className={`p-3 rounded-lg mb-4 border ${sentToDirector ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                    <div className="flex items-center gap-2 mb-1">
                        <div className={`w-2 h-2 rounded-full ${sentToDirector ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`}></div>
                        <span className={`text-[10px] font-bold uppercase tracking-widest ${sentToDirector ? 'text-green-400' : 'text-red-400'}`}>
                            {sentToDirector ? 'Synced to Director' : 'Sync Failed'}
                        </span>
                    </div>
                    {!sentToDirector && (
                        <p className="text-[9px] text-gray-400">
                             無法連線到老師電腦。請確認老師已開啟網頁，或重新掃描 QR Code。
                        </p>
                    )}
                </div>

                <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-2">Performer</div>
                <div className="text-xl font-display font-medium text-white mb-2">{studentName}</div>
                
                <div className="h-px bg-white/10 my-3"></div>

                <div className="bg-white/5 rounded border border-white/10 p-2 mb-2 text-left animate-fade-in">
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                             <div className="text-[9px] text-gray-500 uppercase tracking-wider">Time</div>
                             <div className="text-[10px] font-mono text-white">{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                        </div>
                        <div>
                             <div className="text-[9px] text-gray-500 uppercase tracking-wider">Attempts</div>
                             <div className={`text-[10px] font-bold ${attempts > 0 ? 'text-red-400' : 'text-green-400'}`}>
                                {attempts + 1}
                             </div>
                        </div>
                         <div className="col-span-2">
                             <div className="text-[9px] text-gray-500 uppercase tracking-wider">Elevation</div>
                             <div className="text-[10px] font-mono text-stage-gold">
                                 {capturedLoc?.altitude ? `${Math.round(capturedLoc.altitude)}m (~${estimatedFloor}F)` : 'N/A'}
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="relative z-10 flex items-center justify-center gap-2 text-[10px] text-gray-500 uppercase tracking-widest w-full">
                <span className={`w-2 h-2 rounded-full ${isTruant ? 'bg-red-500' : 'bg-green-500'} animate-pulse`}></span>
                GPS Active
                
                <button 
                    onClick={() => setShowDebugInfo(!showDebugInfo)}
                    className={`ml-2 p-1 rounded hover:bg-white/10 transition-all ${showDebugInfo ? 'text-red-400 opacity-100' : 'text-gray-600 opacity-30 hover:opacity-100'}`}
                >
                    <ShieldCheckIcon className="w-4 h-4" />
                </button>
            </div>
            
             {showDebugInfo && (
                <div className="relative z-10 mt-4 text-[9px] font-mono text-gray-600 bg-black/50 p-2 rounded">
                    Lat: {capturedLoc?.lat.toFixed(4)}, Lng: {capturedLoc?.lng.toFixed(4)}
                </div>
             )}
        </div>
    );
  }

  // Name Input & Scanning Steps (Unchanged basically, just rendering logic)
  return (
    <div className="min-h-screen flex flex-col bg-stage-900 font-sans text-gray-200 relative overflow-hidden">
        {/* Connection Status Badge */}
        {p2pStatus && (
            <div className="absolute top-4 right-4 z-50">
                 <div className={`flex items-center gap-2 px-3 py-1 rounded-full border bg-black/40 backdrop-blur ${p2pStatus === 'connected' ? 'border-green-500/50 text-green-400' : 'border-gray-500/50 text-gray-400'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${p2pStatus === 'connected' ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                    <span className="text-[9px] font-bold uppercase tracking-wider">
                        {p2pStatus === 'connected' ? 'Live Connected' : 'Offline'}
                    </span>
                </div>
            </div>
        )}

        {/* ... (Existing render logic for name-input, locating, fail steps) ... */}
        
        <div className="absolute top-[-20%] right-[-20%] w-[80%] h-[80%] bg-purple-900/20 rounded-full blur-[100px]"></div>

        <div className="relative z-10 px-8 pt-20 pb-4 text-center">
            <h1 className="text-2xl font-display font-medium text-white mb-2">Stage Door</h1>
            <p className="text-stage-accent text-xs uppercase tracking-[0.2em] font-bold">
                {step === 'name-input' ? 'IDENTIFICATION' : 'VERIFICATION'}
            </p>
        </div>

        <div className="relative z-10 flex-1 px-8 flex flex-col justify-center max-w-md mx-auto w-full">
            
            {/* Step 1: Name Input */}
            {step === 'name-input' && (
                <div className="animate-fade-in w-full">
                    <div className="group relative mb-8">
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-4">Name / 姓名</label>
                        <input 
                            type="text"
                            className="w-full py-4 bg-transparent border-b border-white/20 text-2xl text-white focus:outline-none focus:border-stage-gold transition-all font-display placeholder-white/10"
                            placeholder="輸入學號或姓名..."
                            value={studentName}
                            onChange={e => setStudentName(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleNameSubmit()}
                        />
                         <p className="mt-4 text-[9px] text-gray-500">
                             * 系統將自動根據時間鎖定課程<br/>
                             * 失敗兩次將鎖定帳號
                         </p>
                    </div>
                    <button 
                        onClick={handleNameSubmit}
                        disabled={!studentName.trim()}
                        className="w-full bg-white text-black py-5 rounded-lg font-bold text-sm tracking-[0.2em] uppercase hover:bg-gray-200 transition-all disabled:opacity-30 shadow-[0_0_30px_rgba(255,255,255,0.15)] flex items-center justify-center gap-2"
                    >
                        Auto Check-in <ArrowRightIcon className="w-4 h-4" />
                    </button>
                    {errorMsg && <p className="mt-6 text-red-400 text-center text-xs tracking-wider font-bold animate-pulse">{errorMsg}</p>}
                </div>
            )}

            {/* Step 3: Locating (Precision Scan) */}
            {step === 'locating' && (
                <div className="flex flex-col items-center py-10 animate-fade-in w-full">
                    <div className="relative w-24 h-24 mb-8 flex items-center justify-center">
                        <div className="absolute inset-0 border-2 border-stage-gold/30 rounded-full animate-ping"></div>
                        <div className="absolute inset-6 border-2 border-stage-gold/50 rounded-full animate-ping" style={{animationDelay: '0.3s'}}></div>
                        <MapPinIcon className="w-10 h-10 text-stage-gold relative z-10" />
                    </div>
                    
                    <div className="w-full max-w-xs bg-white/10 rounded-full h-1 mb-4 overflow-hidden relative">
                        <div 
                            className="bg-stage-gold h-full transition-all duration-100 ease-linear"
                            style={{ width: `${scanProgress}%` }}
                        ></div>
                    </div>

                    <p className="text-white text-sm font-bold tracking-widest uppercase mb-1">Calibrating...</p>
                    <p className="text-gray-400 text-[10px] tracking-wider mb-2">
                         正在進行加權逆變異數運算 ({sampleCount} samples)
                    </p>
                    
                    {currentAccuracy && (
                         <p className="text-stage-accent text-[9px] font-mono animate-pulse mt-1">
                            Signal Quality: ±{Math.round(currentAccuracy)}m
                         </p>
                    )}
                </div>
            )}

            {/* Step 4: Fail */}
            {step === 'fail' && (
                <div className="flex flex-col items-center animate-fade-in px-4">
                    <div className="w-20 h-20 rounded-full bg-red-900/20 border border-red-500/50 text-red-500 flex items-center justify-center mb-6 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
                        <XMarkIcon className="w-10 h-10" />
                    </div>
                    <h3 className="text-xl font-display text-white mb-3">Verification Failed</h3>
                    <p className="text-center text-gray-400 mb-8 text-sm leading-relaxed border border-white/10 p-4 rounded bg-black/20">
                        {errorMsg}
                    </p>
                    <div className="text-red-400 text-[10px] uppercase tracking-widest font-bold mb-8">
                        Warning: {MAX_ATTEMPTS - attempts} attempt(s) remaining
                    </div>
                    
                    <button onClick={() => setStep('name-input')} className="text-white text-xs font-bold uppercase tracking-widest border-b border-white pb-1 hover:text-stage-gold hover:border-stage-gold transition-colors">
                        Retry (重試)
                    </button>
                </div>
            )}
        </div>
    </div>
  );
};

export default StudentCheckInView;