import React, { useState, useEffect } from 'react';
import { Classroom, Student, AttendanceStatus, ClassSession, AttendanceRecord } from '../types';
import { UserIcon, CheckIcon, XMarkIcon, SparklesIcon, ChevronLeftIcon, QrCodeIcon, MapPinIcon, LinkIcon, ShieldCheckIcon, CameraIcon, QuestionMarkIcon } from '../components/Icon';
import { generateAttendanceInsight } from '../services/geminiService';
import { peerService } from '../services/peerService';

const CountUp = ({ end, className }: { end: number, className?: string }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const duration = 1000;
    const increment = end / (duration / 16); 
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.ceil(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [end]);
  return <span className={className}>{count}</span>;
};

interface AttendanceViewProps {
  classroom: Classroom;
  onBack: () => void;
  onSaveSession: (classId: string, session: ClassSession) => void;
  onTestMode: (lat: number, lng: number, cls: string) => void;
  onKioskMode?: () => void;
  p2pStatus?: string;
}

const AttendanceView: React.FC<AttendanceViewProps> = ({ classroom, onBack, onSaveSession, onTestMode, onKioskMode, p2pStatus }) => {
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [records, setRecords] = useState<Record<string, AttendanceStatus>>({});
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  
  // Dynamic QR Code generation state
  const [qrUrl, setQrUrl] = useState('');
  const [customHost, setCustomHost] = useState('');
  
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [lockedCoords, setLockedCoords] = useState<{lat: number, lng: number} | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  
  // Admin Mode State (To toggle sensitive GPS coordinates only)
  const [isAdminMode, setIsAdminMode] = useState(false);
  const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

  useEffect(() => {
    const existingSession = classroom.sessions.find(s => s.date === date);
    if (existingSession) {
      const newRecords: Record<string, AttendanceStatus> = {};
      Object.values(existingSession.records).forEach((r: AttendanceRecord) => {
        newRecords[r.studentId] = r.status;
      });
      setRecords(newRecords);
    } else {
      const initial: Record<string, AttendanceStatus> = {};
      classroom.students.forEach(s => { initial[s.id] = AttendanceStatus.UNSET; });
      setRecords(initial);
    }
    setInsight(null);
  }, [date, classroom]);

  // Handle Modal Open - Check for localhost vs Cloud
  useEffect(() => {
      if (showQrModal) {
          const currentUrl = window.location.href;
          const urlObj = new URL(currentUrl);
          
          if (isLocalhost) {
             // If localhost, clear to force user input
             setCustomHost(''); 
          } else {
             // If Cloud (Vercel/Firebase), AUTOMATICALLY set the host
             // No need for user to type anything.
             const cleanOrigin = urlObj.origin + urlObj.pathname;
             setCustomHost(cleanOrigin);
          }
      }
  }, [showQrModal, isLocalhost]);

  // Effect to update QR URL
  useEffect(() => {
      if (showQrModal && roomId && lockedCoords) {
          let base = customHost.trim();
          
          // If empty, do not generate QR (prevents invalid QR)
          if (!base) {
              setQrUrl('');
              return;
          }

          // Clean up the URL
          base = base.replace(/\/$/, '');
          base = base.split('?')[0];

          // AUTO-FIX: Ensure protocol exists. 
          if (!base.startsWith('http://') && !base.startsWith('https://')) {
             base = `http://${base}`;
          }
          
          // AUTO-FIX: Ensure Port exists (React default is 3000)
          // Only apply logic if looking like IP and not localhost
          if (!base.match(/:\d+$/) && base.match(/\d+\.\d+\.\d+\.\d+/)) {
              base = `${base}:3000`;
          }

          // Construct final URL
          const newUrl = `${base}?room=${roomId}&lat=${lockedCoords.lat.toFixed(5)}&lng=${lockedCoords.lng.toFixed(5)}&cls=${encodeURIComponent(classroom.name)}`;
          setQrUrl(newUrl);
      }
  }, [customHost, roomId, lockedCoords, showQrModal, classroom.name]);

  const setStatusDirect = (studentId: string, status: AttendanceStatus) => {
    setRecords(prev => ({ ...prev, [studentId]: status }));
  };

  const handleSave = () => {
    const sessionRecords: Record<string, AttendanceRecord> = {};
    Object.entries(records).forEach(([sid, status]) => {
        const currentStatus = status as AttendanceStatus;
        if (currentStatus !== AttendanceStatus.UNSET) {
            // Preserve existing location/address if possible
            const existingSession = classroom.sessions.find(s => s.date === date);
            const existingRecord = existingSession?.records[sid];
            
            sessionRecords[sid] = { 
                studentId: sid, 
                status: currentStatus, 
                timestamp: existingRecord ? existingRecord.timestamp : Date.now(),
                location: existingRecord?.location,
                address: existingRecord?.address,
                checkInAttempts: existingRecord?.checkInAttempts
            };
        }
    });
    onSaveSession(classroom.id, { id: date, date, records: sessionRecords });
    onBack();
  };

  const handleStartLiveSession = () => {
    setLocationStatus('loading');
    setLockedCoords(null);
    
    // 1. Initialize P2P Host
    const newRoomId = peerService.generateRoomId();
    setRoomId(newRoomId);
    peerService.initializeHost(newRoomId);

    // 2. Locate Teacher
    // PRIORITY: Check for Default/Fixed Location
    if (classroom.defaultLocation && classroom.defaultLocation.lat !== 0) {
        setLockedCoords({ lat: classroom.defaultLocation.lat, lng: classroom.defaultLocation.lng });
        setLocationStatus('success');
        setShowQrModal(true);
        return;
    }

    // FALLBACK: Use Teacher's current device location
    if (!navigator.geolocation) {
        alert("Geolocation not supported / 不支援地理位置");
        setLocationStatus('error');
        return;
    }
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            setLockedCoords({ lat: latitude, lng: longitude }); 
            setLocationStatus('success');
            setShowQrModal(true);
        },
        (error) => {
            console.error(error);
            // Allow opening anyway for test mode
            alert("無法取得 GPS，將使用預設座標 (Test Mode)");
            setLockedCoords({ lat: 25.0330, lng: 121.5654 }); 
            setLocationStatus('error');
            setShowQrModal(true);
        },
        { enableHighAccuracy: true }
    );
  };

  const getAnimationClass = (index: number) => {
    const mod = index % 3;
    if (mod === 0) return 'animate-float-slow';
    if (mod === 1) return 'animate-float';
    return 'animate-float-fast';
  };

  const stats = {
    present: Object.values(records).filter(s => s === AttendanceStatus.PRESENT).length,
    absent: Object.values(records).filter(s => s === AttendanceStatus.ABSENT).length,
    total: classroom.students.length
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden relative">
      {/* Header */}
      <div className="sticky top-0 z-20 px-6 py-5 flex items-center justify-between border-b border-white/5 bg-stage-900/40 backdrop-blur-md">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-400 hover:text-white transition-colors">
          <ChevronLeftIcon className="w-6 h-6" />
        </button>
        <div className="text-center">
            <h2 className="font-display text-xl text-white tracking-wide drop-shadow-md">{classroom.name}</h2>
            <div className="flex flex-col items-center">
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="text-[10px] font-bold text-stage-accent bg-transparent text-center focus:outline-none uppercase tracking-[0.2em] cursor-pointer mt-1"/>
                {roomId && (
                    <span className="text-[9px] text-green-400 font-bold uppercase tracking-wide flex items-center gap-1 mt-1 animate-pulse">
                        ● LIVE ROOM: {roomId}
                    </span>
                )}
            </div>
        </div>
        
        {/* Admin Mode Toggle */}
        <div className="w-10 flex justify-end">
            <button 
                onClick={() => setIsAdminMode(!isAdminMode)}
                className={`p-2 transition-colors ${isAdminMode ? 'text-red-500 animate-pulse' : 'text-gray-600 hover:text-gray-400'}`}
                title="Toggle GPS Debug Info"
            >
                <ShieldCheckIcon className="w-5 h-5" />
            </button>
        </div>
      </div>

      {/* Stats 3D Panels */}
      <div className="px-6 py-6 grid grid-cols-3 gap-4 animate-fade-in perspective-container relative z-10">
        <div className="glass-stage rounded-xl p-3 flex flex-col items-center card-3d border-t-2 border-t-stage-gold/30">
            <span className="text-[9px] font-bold text-stage-gold uppercase tracking-widest mb-2">On Set</span>
            <CountUp end={stats.present} className="text-3xl font-display text-white drop-shadow-[0_0_10px_rgba(252,211,77,0.3)]" />
        </div>
        <div className="glass-stage rounded-xl p-3 flex flex-col items-center card-3d border-t-2 border-t-red-500/30">
            <span className="text-[9px] font-bold text-red-400 uppercase tracking-widest mb-2">Missing</span>
            <CountUp end={stats.absent} className="text-3xl font-display text-white/80" />
        </div>
        <div className="glass-stage rounded-xl p-3 flex flex-col items-center card-3d border-t-2 border-t-white/10">
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-2">Total</span>
            <span className="text-3xl font-display text-gray-400">{stats.total}</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex px-6 gap-3 mb-6 animate-fade-in relative z-10">
        <button onClick={handleStartLiveSession} className="flex-1 glass-stage border border-white/10 text-gray-300 py-3 rounded-lg shadow-lg font-bold text-[10px] hover:border-stage-accent hover:text-stage-accent hover:bg-stage-accent/10 active:scale-95 transition-all flex items-center justify-center gap-2 uppercase tracking-wider">
            <QrCodeIcon className="w-4 h-4" /> 
            Live Session QR
        </button>
        {onKioskMode && (
             <button onClick={onKioskMode} className="flex-1 glass-stage border border-white/10 text-gray-300 py-3 rounded-lg shadow-lg font-bold text-[10px] hover:border-stage-gold hover:text-stage-gold hover:bg-stage-gold/10 active:scale-95 transition-all flex items-center justify-center gap-2 uppercase tracking-wider">
                <CameraIcon className="w-4 h-4" /> 
                Kiosk (本機)
            </button>
        )}
      </div>
      
      {/* Insight Panel */}
      {insight && (
          <div className="px-6 mb-6 animate-fade-in relative z-10">
            <div className="glass-stage p-5 rounded-lg border-l-2 border-stage-gold text-sm text-gray-300 italic font-serif leading-relaxed shadow-[0_0_20px_rgba(252,211,77,0.1)]">
                "{insight}"
            </div>
          </div>
      )}

      {/* Student List */}
      <div className="flex-1 overflow-y-auto px-6 pb-28 space-y-3 no-scrollbar rounded-t-2xl pt-2 relative z-10">
        {classroom.students.length === 0 ? (
            <div className="text-center text-gray-500 py-20 font-display italic">
                Stage is empty.
            </div>
        ) : (
            classroom.students.map((student, idx) => {
                const isPresent = records[student.id] === AttendanceStatus.PRESENT;
                const sessionData = classroom.sessions.find(s => s.date === date);
                const recordData = sessionData?.records[student.id];
                const location = recordData?.location;
                const address = recordData?.address;
                const attempts = recordData?.checkInAttempts;
                const timestamp = recordData?.timestamp;
                
                const getFloorDisplay = () => {
                   if (!location || location.altitude === undefined || location.altitude === null) return "Elev: N/A";
                   const fl = Math.max(1, Math.floor(location.altitude / 3.5));
                   return `${fl}F (${Math.round(location.altitude)}m)`;
                };

                return (
                <div key={student.id} 
                     className="glass-stage rounded-xl flex items-center justify-between p-4 animate-fade-in hover:bg-white/5 transition-all duration-500 group relative overflow-hidden"
                     style={{ animationDelay: `${idx * 50}ms` }}
                >
                    {isPresent && <div className="absolute inset-0 bg-stage-gold/5 animate-pulse"></div>}

                    <div className="flex items-center gap-4 relative z-10 flex-1 min-w-0">
                        <div 
                            className={`w-12 h-12 rounded-full border-2 flex items-center justify-center text-gray-400 font-display text-lg transition-all duration-500 flex-shrink-0 ${getAnimationClass(idx)} ${isPresent ? 'bg-stage-gold text-black border-stage-gold shadow-[0_0_20px_rgba(252,211,77,0.6)] animate-pulse-glow' : 'bg-black/40 border-white/10 group-hover:border-white/50'}`}
                        >
                            {student.name.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className={`font-medium text-base transition-colors truncate ${isPresent ? 'text-white' : 'text-gray-300'}`}>{student.name}</div>
                            {isPresent && (
                                <div className="flex flex-col mt-0.5">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <div className="text-[9px] text-stage-gold uppercase tracking-widest font-bold bg-stage-gold/10 px-1.5 py-0.5 rounded">Live</div>
                                        {timestamp && (
                                            <div className="text-[9px] text-white/70 font-mono">
                                                {new Date(timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                            </div>
                                        )}
                                        {attempts !== undefined && (
                                            <div className={`text-[9px] font-bold ${attempts > 1 ? 'text-red-400' : 'text-green-400'}`}>
                                                {attempts} Try
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-2 mt-1">
                                         <div className="text-[9px] text-stage-accent/80 font-mono border border-stage-accent/20 px-1.5 py-0.5 rounded">
                                             {getFloorDisplay()}
                                         </div>
                                    </div>
                                    {isAdminMode && location && (
                                        <div className="flex flex-col gap-0.5 mt-2 border-t border-white/10 pt-1">
                                            <div className="flex items-center gap-1 text-[8px] text-red-300 font-mono tracking-wide">
                                                <MapPinIcon className="w-2 h-2" />
                                                {location.lat.toFixed(5)}, {location.lng.toFixed(5)} (±{Math.round(location.accuracy || 0)}m)
                                            </div>
                                            {address && (
                                                <div className="text-[9px] text-gray-500 font-sans tracking-wide leading-tight truncate">
                                                    {address}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                    
                    <div className="flex gap-2 items-center relative z-10 pl-2">
                        <button onClick={() => setStatusDirect(student.id, AttendanceStatus.PRESENT)} className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${records[student.id] === AttendanceStatus.PRESENT ? 'bg-stage-gold text-black scale-110' : 'bg-white/5 text-gray-500 hover:text-white hover:bg-white/10'}`}>
                            <CheckIcon className="w-4 h-4" />
                        </button>
                        <button onClick={() => setStatusDirect(student.id, AttendanceStatus.ABSENT)} className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${records[student.id] === AttendanceStatus.ABSENT ? 'bg-red-600 text-white scale-110' : 'bg-white/5 text-gray-500 hover:text-white hover:bg-white/10'}`}>
                            <XMarkIcon className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            )})
        )}
      </div>

      {/* Floating Save Button */}
      <div className="absolute bottom-8 left-0 right-0 px-6 flex justify-center z-30 pointer-events-none perspective-container">
          <button 
            onClick={handleSave}
            className="pointer-events-auto bg-white text-black px-10 py-3 rounded-full shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:scale-105 active:scale-95 transition-all flex items-center gap-2 uppercase tracking-widest text-xs font-bold card-3d"
          >
            Wrap Session
          </button>
      </div>

      {/* QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-xl z-50 flex flex-col items-center justify-center p-6 animate-fade-in overflow-y-auto">
            <div className="glass-stage p-5 rounded-2xl shadow-[0_0_50px_rgba(56,189,248,0.2)] mb-8 border border-white/20 relative min-h-[300px] flex items-center justify-center bg-black/50">
                <div className="absolute -top-10 -left-10 w-20 h-20 bg-stage-accent/30 rounded-full blur-xl"></div>
                <div className="absolute -bottom-10 -right-10 w-20 h-20 bg-stage-gold/30 rounded-full blur-xl"></div>
                
                {qrUrl ? (
                     <img src={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrUrl)}`} alt="Check-in QR" className="w-64 h-64 rounded-lg relative z-10 bg-white" />
                ) : (
                    <div className="text-center p-4 relative z-10">
                        <p className="text-red-400 font-bold mb-2 uppercase tracking-widest text-sm">Waiting for valid host...</p>
                        {isLocalhost && <p className="text-gray-500 text-xs">請在下方輸入電腦 IP 位址</p>}
                    </div>
                )}
            </div>
            
            <div className="flex flex-col items-center mb-10 space-y-3 w-full max-w-xs">
                {/* Connection Status Indicator */}
                <div className={`flex items-center gap-2 px-4 py-1 rounded-full border ${p2pStatus === 'connected' ? 'border-green-500/50 bg-green-500/10 text-green-400' : 'border-red-500/50 bg-red-500/10 text-red-400'}`}>
                    <div className={`w-2 h-2 rounded-full ${p2pStatus === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                    <span className="text-[10px] font-bold uppercase tracking-wider">
                        {p2pStatus === 'connected' ? `Live: ${roomId}` : 'Waiting for connection...'}
                    </span>
                </div>

                <div className="w-full">
                     {isLocalhost ? (
                        <>
                             <label className="text-[9px] text-gray-500 uppercase font-bold block mb-1">
                                 Server Address (Host IP)
                             </label>
                             <div className="relative">
                                 <input 
                                    className={`w-full bg-black/50 border rounded px-3 py-2 text-xs mb-2 focus:outline-none focus:border-stage-accent transition-colors ${!qrUrl ? 'border-red-500 text-red-400' : 'border-white/20 text-white'}`}
                                    value={customHost}
                                    onChange={(e) => setCustomHost(e.target.value)}
                                    placeholder="e.g. 192.168.1.105:3000"
                                 />
                                 {!qrUrl && (
                                     <div className="absolute right-3 top-2 animate-pulse text-red-500">
                                         !
                                     </div>
                                 )}
                             </div>
                             {!qrUrl && (
                                 <div className="text-[9px] text-red-400 font-bold mb-2 border border-red-500/30 p-2 rounded bg-red-500/10 animate-fade-in">
                                    ⚠️ LOCALHOST DETECTED<br/>
                                    <span className="text-gray-300 font-normal mt-1 block">
                                        手機無法識別 "localhost"。請輸入 IP (如: 192.168.x.x)。
                                    </span>
                                 </div>
                             )}
                         </>
                     ) : (
                        <div className="text-center bg-green-500/10 border border-green-500/30 rounded p-2 mb-3">
                             <div className="text-[9px] font-bold text-green-400 uppercase tracking-wider">Cloud Mode Active</div>
                             <div className="text-[9px] text-gray-400 truncate mt-1">{customHost}</div>
                        </div>
                     )}
                </div>

                <div className="flex items-center gap-3 text-stage-accent bg-stage-accent/10 px-6 py-2 rounded-full border border-stage-accent/30 shadow-[0_0_15px_rgba(56,189,248,0.1)] mb-4">
                    <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-stage-accent opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
                    </span>
                    <span className="font-bold text-[10px] tracking-[0.2em] uppercase">
                        {lockedCoords ? 'GPS Locked' : 'Locating...'}
                    </span>
                </div>
                
                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3 w-full mb-2">
                    <button 
                        onClick={() => { 
                            if(qrUrl) {
                                navigator.clipboard.writeText(qrUrl); 
                                alert('連結已複製 (Link Copied!)'); 
                            } else {
                                alert('請先輸入有效的 IP 位址');
                            }
                        }}
                        className="bg-white/10 hover:bg-white/20 text-white py-3 rounded-lg text-[10px] font-bold uppercase tracking-wider border border-white/10 transition-colors flex items-center justify-center gap-2"
                    >
                        <LinkIcon className="w-3 h-3" />
                        Copy Link
                    </button>
                    {lockedCoords && (
                        <button 
                            onClick={() => onTestMode(lockedCoords.lat, lockedCoords.lng, classroom.name)}
                            className="bg-stage-gold/20 hover:bg-stage-gold/30 text-stage-gold py-3 rounded-lg text-[10px] font-bold uppercase tracking-wider border border-stage-gold/30 transition-colors flex items-center justify-center gap-2"
                        >
                            <UserIcon className="w-3 h-3" />
                            Test Check-in
                        </button>
                    )}
                </div>
            </div>

            <button onClick={() => setShowQrModal(false)} className="text-gray-500 hover:text-white transition-colors text-xs tracking-widest uppercase font-bold border-b border-transparent hover:border-white pb-1">
                Close
            </button>
        </div>
      )}
    </div>
  );
};

export default AttendanceView;